#!/usr/bin/env python3
"""
Yılbaşı çekilişi - şifreli veri üretici (GitHub Pages için)

Kurulum:   pip install cryptography
Kullanım:  python olustur.py katilimcilar.csv

Çıktı: data.json  (bunu GitHub'a yükle)
katilimcilar.csv dosyasını GitHub'a YÜKLEME (.gitignore bunu engeller).

Her kişinin "kime hediye alacağı" bilgisi, kendi mail adresinden türetilen
anahtarla şifrelenir. Eşleşmeler ekrana yazdırılmaz.
"""
import base64
import csv
import hashlib
import json
import os
import secrets
import sys

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

ITERASYON = 250_000
CIKTI = "data.json"


def b64(b):
    return base64.b64encode(b).decode()


def mail_duzelt(m):
    return m.strip().lower()


def listeyi_oku(yol):
    kisiler = []
    with open(yol, newline="", encoding="utf-8-sig") as f:
        for satir in csv.DictReader(f):
            isim = (satir.get("isim") or "").strip()
            mail = mail_duzelt(satir.get("mail") or "")
            if isim and mail:
                kisiler.append({"isim": isim, "mail": mail})
    return kisiler


def kontrol(kisiler):
    if len(kisiler) < 3:
        sys.exit("Çekiliş için en az 3 kişi gerekir.")
    if len({k["mail"] for k in kisiler}) != len(kisiler):
        sys.exit("Listede aynı mail birden fazla kez geçiyor.")
    if len({k["isim"].lower() for k in kisiler}) != len(kisiler):
        sys.exit("Listede aynı isim birden fazla kez geçiyor.")
    for k in kisiler:
        if "@" not in k["mail"]:
            sys.exit(f"Geçersiz mail: {k['mail']}")


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    yeniden = "--yeniden" in sys.argv
    if not args:
        sys.exit(__doc__)

    if os.path.exists(CIKTI) and not yeniden:
        sys.exit(
            f"{CIKTI} zaten var. Çekilişi yanlışlıkla bozmamak için durdum.\n"
            "Gerçekten baştan çekmek istiyorsan --yeniden ekle "
            "(herkesin sonucu değişir!)."
        )

    kisiler = listeyi_oku(args[0])
    kontrol(kisiler)

    # Karıştır, herkesi bir sonrakine eşle (tek halka: kimse kendine çıkmaz,
    # karşılıklı eşleşme olmaz)
    sirali = kisiler[:]
    secrets.SystemRandom().shuffle(sirali)
    n = len(sirali)

    tuz = secrets.token_bytes(16)
    kayitlar = {}
    for i, veren in enumerate(sirali):
        alan = sirali[(i + 1) % n]
        kimlik = hashlib.sha256(tuz + b"id" + veren["mail"].encode()).hexdigest()
        anahtar = hashlib.pbkdf2_hmac(
            "sha256", veren["mail"].encode(), tuz + b"key", ITERASYON, dklen=32
        )
        iv = secrets.token_bytes(12)
        ct = AESGCM(anahtar).encrypt(iv, alan["isim"].encode("utf-8"), None)
        kayitlar[kimlik] = {"iv": b64(iv), "ct": b64(ct)}

    # Kayıt sırası da bilgi sızdırmasın diye karıştır
    anahtarlar = list(kayitlar)
    secrets.SystemRandom().shuffle(anahtarlar)
    veri = {
        "tuz": b64(tuz),
        "iterasyon": ITERASYON,
        "kayitlar": {k: kayitlar[k] for k in anahtarlar},
    }
    with open(CIKTI, "w", encoding="utf-8") as f:
        json.dump(veri, f)

    print(f"{n} kişi için çekiliş yapıldı ve {CIKTI} oluşturuldu.")
    print("Eşleşmeler kasıtlı olarak ekrana yazdırılmadı.")
    print("Şimdi index.html ve data.json dosyalarını GitHub'a yükleyebilirsin.")


if __name__ == "__main__":
    main()
